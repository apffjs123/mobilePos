package com.cookandroid.se_02_mobilepos_ver2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MenuEdit extends MainActivity {
    Button editChick, editPizza, editSide;
    Button goMain, goBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_edit);

        Button editChick = (Button) findViewById(R.id.editChick);
        Button editPizza = (Button) findViewById(R.id.editPizza);
        Button editSide = (Button) findViewById(R.id.editSide);

        Button goMain = (Button) findViewById(R.id.goMain);
        Button goBack = (Button) findViewById(R.id.goBack);

        editChick.setOnClickListener(
                new Button.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //메뉴에 버튼 추가(db)
                    }
                }
        );
        editPizza.setOnClickListener(
                new Button.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //메뉴에 버튼 수정(db)
                    }
                }
        );
        editSide.setOnClickListener(
                new Button.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //메뉴에 버튼 수정(db)
                    }
                }
        );
        goBack.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(), MenuManage.class);
                        startActivity(intent);
                    }
                }
        );
        goMain.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }
                }
        );

    }
}