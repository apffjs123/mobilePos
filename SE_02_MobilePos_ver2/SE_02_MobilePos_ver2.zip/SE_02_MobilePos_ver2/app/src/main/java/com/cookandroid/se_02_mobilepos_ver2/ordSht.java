package com.cookandroid.se_02_mobilepos_ver2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by LG on 2018-12-20.
 */

public class ordSht extends AppCompatActivity {

    EditText edtOdSt;
    Button goMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ordsht);

        edtOdSt = (EditText) findViewById(R.id.edtOdSt);
        goMain = (Button)findViewById(R.id.goMain);
    //메인으로 돌아가기
        goMain.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }
                });


    }
}
